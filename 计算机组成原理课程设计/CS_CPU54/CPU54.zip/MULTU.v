`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/05 22:12:29
// Design Name: 
// Module Name: MULTU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module MULU(//�޷�����
    input  [31:0] a,        // ����ĳ���A
    input  [31:0] b,        // ����ĳ���B
    output [31:0] HI,       // ��32λ���
    output [31:0] LO        // ��32λ���
);
    wire [63:0] z;
    assign z = a * b;
    assign HI = z[63:32]; 
    assign LO = z[31:0];
endmodule