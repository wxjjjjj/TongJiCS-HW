`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/08 20:22:56
// Design Name: 
// Module Name: DIVU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module DIVU(
    input  [31:0] dividend,
    input  [31:0] divisor,
    output [31:0] q,
    output [31:0] r
);
    assign q = (divisor != 0) ? dividend / divisor : 32'hffffffff; // 0������
    assign r = (divisor != 0) ? dividend % divisor : dividend;
endmodule