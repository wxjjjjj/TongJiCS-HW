`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/05/15 23:44:33
// Design Name: 
// Module Name: Controller
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Controller(              //�����������ݵ�ǰҪִ�е�ָ���������Ԫ������״̬
    input add_flag,            //ADD
    input addu_flag,           //ADDU
    input sub_flag,            //SUB
    input subu_flag,           //SUBU
    input and_flag,            //AND
    input or_flag,             //OR
    input xor_flag,            //XOR
    input nor_flag,            //NOR
    input slt_flag,            //SLT
    input sltu_flag,           //SLTU
    input sll_flag,            //SLL
    input srl_flag,            //SRL
    input sra_flag,            //SRA
    input sllv_flag,           //SLLV
    input srlv_flag,           //RLV
    input srav_flag,           //SRAV
    input jr_flag,             //JR
    input addi_flag,           //DDI
    input addiu_flag,          //ADDIU
    input andi_flag,           //ANDI
    input ori_flag,            //ORI
    input xori_flag,           //XORI
    input lw_flag,             //LW
    input sw_flag,             //SW
    input beq_flag,            //BEQ
    input bne_flag,            //BNE
    input slti_flag,           //SLTI
    input sltiu_flag,          //SLTIU
    input lui_flag,            //LUI
    input j_flag,              //J
    input jal_flag,            //JAL
    input div_flag,        
    input divu_flag,        
    input mult_flag,        
    input multu_flag,        
    input bgez_flag,        
    input jalr_flag,        
    input lh_flag,       
    input lhu_flag,        
    input lb_flag,      
    input lbu_flag,     
    input sb_flag,      
    input sh_flag,        
    input break_flag,                                               
    input syscall_flag,       
    input eret_flag,      
    input mfhi_flag,       
    input mflo_flag,        
    input mthi_flag,       
    input mtlo_flag,       
    input mfc0_flag,     
    input mtc0_flag,        
    input clz_flag,       
    input teq_flag,
    /* �����õ���Ԫ����ָ�����ﶼ���漰�� */
    input zero,                //ALU��־λZF
    input sign_flag,           //BGEZָ���ã��Ƿ�Ϊ����sf����λ
    output reg_w,              //RegFile�Ĵ������Ƿ��д��
    output [3:0] aluc,         //ALUC��ָ�����ALUCִ�к��ֲ���
    output dm_r,               //DMEM�Ƿ��д��
    output dm_w,               //�Ƿ��DMEM�ж�ȡ����
    output HI_w,               //HI�Ƿ��д��
    output LO_w,               //LO�Ƿ��д��
    output [3:0] ext_ena,      //EXT��չ�Ƿ�����4��״̬�ֱ��ӦEXT5��EXT16��EXT16(S)��EXT18(S),����EXT[0]��ӦEXT5
    output cat_ena,            //�Ƿ���Ҫƴ��
    output [27:0] mux           //27����·ѡ������״̬
    );
/* �����Ǹ�ֵ��Ҳ���Ǹ���Ҫִ�еĲ���������Ԫ������״̬ */
assign reg_w = (!jr_flag && !sw_flag && !beq_flag && !bne_flag && !j_flag &&
                !div_flag && !divu_flag && !mult_flag && !multu_flag &&
                !bgez_flag && !sb_flag && !sh_flag && !break_flag &&
                !syscall_flag && !eret_flag && !mthi_flag && !mtlo_flag &&
                !mtc0_flag && !teq_flag) ? 1'b1 : 1'b0;

assign aluc[3] = (slt_flag  || sltu_flag  || sllv_flag || srlv_flag ||
                  srav_flag || sll_flag   || srl_flag  || sra_flag  || 
                  slti_flag || sltiu_flag || lui_flag) ? 1'b1 : 1'b0;
                  
assign aluc[2] = (and_flag  || or_flag    || xor_flag  || nor_flag  ||
                  sllv_flag || srlv_flag  || srav_flag || sll_flag  ||
                  srl_flag  || sra_flag   || andi_flag || ori_flag  ||
                  xori_flag) ? 1'b1 : 1'b0;
                  
assign aluc[1] = (add_flag  || sub_flag   || xor_flag  || nor_flag  ||
                  slt_flag  || sltu_flag  || sllv_flag || sll_flag  ||
                  addi_flag || xori_flag  || slti_flag || sltiu_flag||
                  bgez_flag ) ? 1'b1 : 1'b0;
                  
assign aluc[0] = (sub_flag  || subu_flag  || or_flag   || nor_flag  ||
                  slt_flag  ||  srlv_flag || beq_flag  || bne_flag  ||
                  srl_flag  || ori_flag   || slti_flag || bgez_flag ||
                  teq_flag ) ? 1'b1 : 1'b0;

assign dm_r = (lw_flag || lh_flag || lhu_flag || lb_flag || lbu_flag) ? 1'b1 : 1'b0;
assign dm_w = (sw_flag || sb_flag || sh_flag) ? 1'b1 : 1'b0;

assign HI_w=(div_flag || divu_flag || mult_flag || multu_flag || mthi_flag)? 1'b1 : 1'b0;
assign LO_w=(div_flag || divu_flag || mult_flag || multu_flag || mtlo_flag)? 1'b1 : 1'b0;

assign ext_ena[3] = (beq_flag  || bne_flag || bgez_flag) ? 1'b1 : 1'b0;                              //EXT18(S)

assign ext_ena[2] = (addi_flag || addiu_flag || lw_flag   || sw_flag ||
                     slti_flag || sltiu_flag || lh_flag   || lhu_flag ||
                     lb_flag   || lbu_flag || sb_flag || sh_flag) ? 1'b1 : 1'b0;                            //EXT16(S)
                  
assign ext_ena[1] = (andi_flag || ori_flag   || xori_flag || lui_flag) ? 1'b1 : 1'b0;   //EXT16
/*2025.5.16 �޸�*/ 
assign ext_ena[0] = (sll_flag  || srl_flag   || sra_flag || sllv_flag ||srlv_flag   || srav_flag) ? 1'b1 : 1'b0;                //EXT5

assign cat_ena = (j_flag || jal_flag) ? 1'b1 : 1'b0;
/*2025.5.16�޸�// 2025.7.9�ٸ�*/
assign mux[27] = (mtlo_flag ) ? 1'b1 : 1'b0;
assign mux[26] = (mthi_flag ) ? 1'b1 : 1'b0;
assign mux[25] = (break_flag ) ? 1'b1 : 1'b0;
assign mux[24] = (syscall_flag ) ? 1'b1 : 1'b0;
assign mux[23] = (mult_flag   || multu_flag) ? 1'b1 : 1'b0;
assign mux[22] = (div_flag ) ? 1'b1 : 1'b0;
assign mux[21] = (mult_flag ) ? 1'b1 : 1'b0;
assign mux[20] = (mult_flag   || multu_flag ) ? 1'b1 : 1'b0;
assign mux[19] = (div_flag ) ? 1'b1 : 1'b0;
assign mux[18] = (mult_flag) ? 1'b1 : 1'b0;
assign mux[17] = (bgez_flag ) ? 1'b0 : 1'b1;
assign mux[16] = (mfhi_flag   || mflo_flag   || mfc0_flag || clz_flag  ) ? 1'b0 : 1'b1;
assign mux[15] = (mfc0_flag   || clz_flag ) ? 1'b1 : 1'b0;
assign mux[14] = (jalr_flag ) ? 1'b0 : 1'b1;
assign mux[13] = (mfhi_flag ) ? 1'b1 : 1'b0;                                                                        
assign mux[12] = (mfc0_flag ) ? 1'b1 : 1'b0;
assign mux[11] = (sll_flag   || srl_flag   || sra_flag  ) ? 1'b1 : 1'b0;

assign mux[10] = (j_flag || jal_flag || beq_flag&&zero ||bne_flag&&!zero || bgez_flag&&!sign_flag) ? 1'b0 : 1'b1;/*MUX10*//*zero=0,beq_flag=1,mux10=0*//*MUX10--���״� */

assign mux[9] = (break_flag   || syscall_flag   || eret_flag || teq_flag&&zero  ) ? 1'b1 : 1'b0;

assign mux[8] = (addi_flag || addiu_flag || andi_flag  ||
                 ori_flag  || xori_flag  || lw_flag    ||
                 sw_flag   || slti_flag  || sltiu_flag ||
                 lui_flag  || lh_flag    || lhu_flag   ||
                 lb_flag   || lbu_flag   || sb_flag    ||
                 sh_flag )? 1'b0 : 1'b1;/*MUX8*/

assign mux[7] = (andi_flag|| ori_flag || xori_flag || lui_flag)? 1'b0 : 1'b1;/*MUX7*/

assign mux[6] = (sll_flag   || srl_flag || sra_flag || sllv_flag  ||
                 srlv_flag  || srav_flag) ? 1'b0 : 1'b1;/*MUX6*/
                 
assign mux[5] =(lw_flag || lh_flag || lhu_flag || lb_flag || lbu_flag) ? 1'b1 : 1'b0;/*MUX5*/

assign mux[4] = (lw_flag   || jal_flag  || lh_flag || lhu_flag || lb_flag || lbu_flag ) ? 1'b0 : 1'b1;/*MUX4*/

assign mux[3] = (eret_flag ) ? 1'b0 : 1'b1;

assign mux[2] = (beq_flag || bne_flag || bgez_flag) ? 1'b1 : 1'b0;/*MUX2*/

assign mux[1] = (jr_flag || jalr_flag) ? 1'b1 : 1'b0;/*MUX1*/
assign mux[0] = mfc0_flag ? 1'b1 : 1'b0;/*MUX0--ѡ��CP0��addr��*/

endmodule
