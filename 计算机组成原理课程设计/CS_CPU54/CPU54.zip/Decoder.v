`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/05/15 23:31:17
// Design Name: 
// Module Name: Decoder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Decoder(                 //���нӿ������ǰ�������ָ���Ҫ����Ϊ���迹
    input  [31:0] instr_in,     //��Ҫ�����ָ�Ҳ���ǵ�ǰҪִ�е�ָ��
    output add_flag,            //ADD
    output addu_flag,           //ADDU
    output sub_flag,            //SUB
    output subu_flag,           //SUBU
    output and_flag,            //AND
    output or_flag,             //OR
    output xor_flag,            //XOR
    output nor_flag,            //NOR
    output slt_flag,            //SLT
    output sltu_flag,           //SLTU
    output sll_flag,            //SLL
    output srl_flag,            //SRL
    output sra_flag,            //SRA
    output sllv_flag,           //SLLV
    output srlv_flag,           //SRLV
    output srav_flag,           //SRAV
    output jr_flag,             //JR
    output addi_flag,           //ADDI
    output addiu_flag,          //ADDIU
    output andi_flag,           //ANDI
    output ori_flag,            //ORI
    output xori_flag,           //XORI
    output lw_flag,             //LW
    output sw_flag,             //SW
    output beq_flag,            //BEQ
    output bne_flag,            //BNE
    output slti_flag,           //SLTI
    output sltiu_flag,          //SLTIU
    output lui_flag,            //LUI
    output j_flag,              //J
    output jal_flag,            //JAL
    output div_flag,        
    output divu_flag,        
    output mult_flag,        
    output multu_flag,        
    output bgez_flag,        
    output jalr_flag,        
    output lh_flag,       
    output lhu_flag,        
    output lb_flag,      
    output lbu_flag,     
    output sb_flag,      
    output sh_flag,        
    output break_flag,                                               
    output syscall_flag,       
    output eret_flag,      
    output mfhi_flag,       
    output mflo_flag,        
    output mthi_flag,       
    output mtlo_flag,       
    output mfc0_flag,     
    output mtc0_flag,        
    output clz_flag,       
    output teq_flag,
    /*������controller�Ŀ����źţ�����ĵ�ַ��ͨ��MUX��RF������*/
    output [4:0]  RsC,          //Rs��Ӧ�ļĴ����ĵ�ַ
    output [4:0]  RtC,          //Rt��Ӧ�ļĴ����ĵ�ַ
    output [4:0]  RdC,          //Rd��Ӧ�ļĴ����ĵ�ַ
    output [4:0]  shamt,        //λ��ƫ������SLL��SRL��SRA�ã�
    output [15:0] immediate,    //��������I��ָ���ã�
    output [25:0] address       //��ת��ַ��J��ָ���ã�
    );
/* ����MIPSָ������ָ����ԭָ���ж�Ӧ�ı��� */
/* ������Щָ�������չ��OP��ȫΪ0����Ҫ�����6λFUNC�������� */
parameter ADD_OPE   = 6'b100000;
parameter ADDU_OPE  = 6'b100001;
parameter SUB_OPE   = 6'b100010;
parameter SUBU_OPE  = 6'b100011;
parameter AND_OPE   = 6'b100100;
parameter OR_OPE    = 6'b100101;
parameter XOR_OPE   = 6'b100110;
parameter NOR_OPE   = 6'b100111;
parameter SLT_OPE   = 6'b101010;
parameter SLTU_OPE  = 6'b101011;

parameter SLL_OPE   = 6'b000000;
parameter SRL_OPE   = 6'b000010;
parameter SRA_OPE   = 6'b000011;

parameter SLLV_OPE  = 6'b000100;
parameter SRLV_OPE  = 6'b000110;
parameter SRAV_OPE  = 6'b000111;

parameter JR_OPE    = 6'b001000;
/* ������Щָ��ͨ��OP��ֱ�Ӽ������� */
parameter ADDI_OPE  = 6'b001000;
parameter ADDIU_OPE = 6'b001001;
parameter ANDI_OPE  = 6'b001100;
parameter ORI_OPE   = 6'b001101;
parameter XORI_OPE  = 6'b001110;
parameter LW_OPE    = 6'b100011;
parameter SW_OPE    = 6'b101011;
parameter BEQ_OPE   = 6'b000100;
parameter BNE_OPE   = 6'b000101;
parameter SLTI_OPE  = 6'b001010;
parameter SLTIU_OPE = 6'b001011;

parameter LUI_OPE   = 6'b001111;

parameter J_OPE     = 6'b000010;
parameter JAL_OPE   = 6'b000011;

/* 54��ָ�����Ӳ��� */
parameter CLZ_OPE     = 6'b100000;
parameter JALR_OPE    = 6'b001001;
parameter MTHI_OPE    = 6'b010001;
parameter MFHI_OPE    = 6'b010000;
parameter MTLO_OPE    = 6'b010011;
parameter MFLO_OPE    = 6'b010010;
parameter SB_OPE      = 6'b101000;
parameter SH_OPE      = 6'b101001;
parameter LB_OPE      = 6'b100000;
parameter LH_OPE      = 6'b100001;
parameter LBU_OPE     = 6'b100100;
parameter LHU_OPE     = 6'b100101;
parameter ERET_OPE    = 6'b011000;
parameter BREAK_OPE   = 6'b001101;
parameter SYSCALL_OPE = 6'b001100;
parameter TEQ_OPE     = 6'b110100;
parameter MFC0_OPE    = 5'b00000;
parameter MTC0_OPE    = 5'b00100; //ע��������ָ���ǿ�������λorder���ֵģ�op��func��һ��
parameter MUL_OPE     = 6'b011000;
parameter MULTU_OPE   = 6'b011001;
parameter DIV_OPE     = 6'b011010;
parameter DIVU_OPE    = 6'b011011;
parameter BGEZ_OPE    = 6'b000001;

/* �����Ǹ�ֵ */
/* ��ָ��������룬�ж����ĸ�ָ�� */
assign add_flag  = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == ADD_OPE )) ? 1'b1 : 1'b0;
assign addu_flag = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == ADDU_OPE)) ? 1'b1 : 1'b0;
assign sub_flag  = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == SUB_OPE )) ? 1'b1 : 1'b0;
assign subu_flag = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == SUBU_OPE)) ? 1'b1 : 1'b0;
assign and_flag  = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == AND_OPE )) ? 1'b1 : 1'b0;
assign or_flag   = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == OR_OPE  )) ? 1'b1 : 1'b0;
assign xor_flag  = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == XOR_OPE )) ? 1'b1 : 1'b0;
assign nor_flag  = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == NOR_OPE )) ? 1'b1 : 1'b0;
assign slt_flag  = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == SLT_OPE )) ? 1'b1 : 1'b0;
assign sltu_flag = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == SLTU_OPE)) ? 1'b1 : 1'b0;

assign sll_flag  = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == SLL_OPE )) ? 1'b1 : 1'b0;
assign srl_flag  = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == SRL_OPE )) ? 1'b1 : 1'b0;
assign sra_flag  = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == SRA_OPE )) ? 1'b1 : 1'b0;

assign sllv_flag = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == SLLV_OPE)) ? 1'b1 : 1'b0;
assign srlv_flag = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == SRLV_OPE)) ? 1'b1 : 1'b0;
assign srav_flag = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == SRAV_OPE)) ? 1'b1 : 1'b0;
assign jr_flag   = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == JR_OPE  )) ? 1'b1 : 1'b0;

assign addi_flag  = (instr_in[31:26] == ADDI_OPE ) ? 1'b1 : 1'b0;
assign addiu_flag = (instr_in[31:26] == ADDIU_OPE) ? 1'b1 : 1'b0;
assign andi_flag  = (instr_in[31:26] == ANDI_OPE ) ? 1'b1 : 1'b0;
assign ori_flag   = (instr_in[31:26] == ORI_OPE  ) ? 1'b1 : 1'b0;
assign xori_flag  = (instr_in[31:26] == XORI_OPE ) ? 1'b1 : 1'b0;
assign lw_flag    = (instr_in[31:26] == LW_OPE   ) ? 1'b1 : 1'b0;
assign sw_flag    = (instr_in[31:26] == SW_OPE   ) ? 1'b1 : 1'b0;
assign beq_flag   = (instr_in[31:26] == BEQ_OPE  ) ? 1'b1 : 1'b0;
assign bne_flag   = (instr_in[31:26] == BNE_OPE  ) ? 1'b1 : 1'b0;
assign slti_flag  = (instr_in[31:26] == SLTI_OPE ) ? 1'b1 : 1'b0;
assign sltiu_flag = (instr_in[31:26] == SLTIU_OPE) ? 1'b1 : 1'b0;

assign lui_flag   = (instr_in[31:26] == LUI_OPE  ) ? 1'b1 : 1'b0;

assign j_flag     = (instr_in[31:26] == J_OPE    ) ? 1'b1 : 1'b0;
assign jal_flag   = (instr_in[31:26] == JAL_OPE  ) ? 1'b1 : 1'b0;

/*���ӵ�23��ָ��*/
assign clz_flag     = ((instr_in[31:26] == 6'b011100) && (instr_in[5:0] == CLZ_OPE )) ? 1'b1 : 1'b0;
assign jalr_flag    = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == JALR_OPE )) ? 1'b1 : 1'b0;
assign mthi_flag    = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == MTHI_OPE )) ? 1'b1 : 1'b0;
assign mtlo_flag    = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == MTLO_OPE )) ? 1'b1 : 1'b0;
assign mfhi_flag     = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == MFHI_OPE )) ? 1'b1 : 1'b0;
assign mflo_flag    = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == MFLO_OPE )) ? 1'b1 : 1'b0;
assign sb_flag      = (instr_in[31:26] == SB_OPE  ) ? 1'b1 : 1'b0;
assign sh_flag      = (instr_in[31:26] == SH_OPE  ) ? 1'b1 : 1'b0;
assign lb_flag      = (instr_in[31:26] == LB_OPE  ) ? 1'b1 : 1'b0;
assign lh_flag      = (instr_in[31:26] == LH_OPE  ) ? 1'b1 : 1'b0;
assign lbu_flag     = (instr_in[31:26] == LBU_OPE ) ? 1'b1 : 1'b0;
assign lhu_flag     = (instr_in[31:26] == LHU_OPE ) ? 1'b1 : 1'b0;
assign eret_flag    = ((instr_in[31:26] == 6'b010000) && (instr_in[5:0] == ERET_OPE    )) ? 1'b1 : 1'b0;
assign break_flag   = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == BREAK_OPE   )) ? 1'b1 : 1'b0;
assign syscall_flag = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == SYSCALL_OPE )) ? 1'b1 : 1'b0;
assign teq_flag     = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == TEQ_OPE     )) ? 1'b1 : 1'b0;
assign mfc0_flag    = ((instr_in[31:26] == 6'b010000) && (instr_in[5:0] == 6'h0) && (instr_in[25:21] == MFC0_OPE)) ? 1'b1 : 1'b0;
assign mtc0_flag    = ((instr_in[31:26] == 6'b010000) && (instr_in[5:0] == 6'h0) && (instr_in[25:21] == MTC0_OPE)) ? 1'b1 : 1'b0;
assign mult_flag    = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == MUL_OPE     )) ? 1'b1 : 1'b0;
assign multu_flag   = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == MULTU_OPE   )) ? 1'b1 : 1'b0;
assign div_flag     = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == DIV_OPE     )) ? 1'b1 : 1'b0;
assign divu_flag    = ((instr_in[31:26] == 6'h0) && (instr_in[5:0] == DIVU_OPE    )) ? 1'b1 : 1'b0;
assign bgez_flag    = ((instr_in[31:26] == BGEZ_OPE) && (instr_in[20:16] == 5'b00001) ) ? 1'b1 : 1'b0;

/* ȡ��ָ���и����ֵ�ֵ */
assign RsC = (add_flag  || addu_flag || sub_flag  || subu_flag  ||
              and_flag  || or_flag   || xor_flag  || nor_flag   ||
              slt_flag  || sltu_flag || sllv_flag || srlv_flag  ||
              srav_flag || jr_flag   || addi_flag || addiu_flag ||
              andi_flag || ori_flag  || xori_flag || lw_flag    ||
              sw_flag   || beq_flag  || bne_flag  || slti_flag  ||
              sltiu_flag ||
              div_flag || divu_flag || mult_flag || multu_flag ||
              bgez_flag || jalr_flag || lh_flag || lhu_flag || lb_flag ||
              lbu_flag || sb_flag || sh_flag || mthi_flag || mtlo_flag ||
              clz_flag || teq_flag ) ? instr_in[25:21] : 5'hz;

assign RtC = (add_flag  || addu_flag  || sub_flag   || subu_flag ||
              and_flag  || or_flag    || xor_flag   || nor_flag  ||
              slt_flag  || sltu_flag  || sll_flag   || srl_flag  ||
              sra_flag  || sllv_flag  || srlv_flag  || srav_flag ||
              sw_flag   || beq_flag   || bne_flag   ||
              div_flag  || divu_flag  || mult_flag  || multu_flag ||
              sb_flag   || sh_flag    ||
              mtc0_flag || teq_flag) ? instr_in[20:16] :((mfc0_flag) ? instr_in[15:11]: 5'hz);

assign RdC = (add_flag  || addu_flag  || sub_flag  || subu_flag  ||
              and_flag  || or_flag    || xor_flag  || nor_flag   ||
              slt_flag  || sltu_flag  || sll_flag  || srl_flag   ||
              sra_flag  || sllv_flag  || srlv_flag || srav_flag  ||
              jalr_flag || mfhi_flag  || mflo_flag || mtc0_flag  ||
              clz_flag  ) ? instr_in[15:11] : ((
              addi_flag || addiu_flag || andi_flag || ori_flag   || 
              xori_flag || lw_flag    || slti_flag || sltiu_flag ||
              lui_flag  ||
              lh_flag   || lhu_flag   || lb_flag   || lbu_flag   ||
              mfc0_flag) ? instr_in[20:16] : (jal_flag ? 5'd31 : 5'hz));

assign shamt = (sll_flag || srl_flag || sra_flag) ? instr_in[10:6] : 5'hz;        

assign immediate = (addi_flag || addiu_flag || andi_flag  || ori_flag || 
                    xori_flag || lw_flag    || sw_flag    || beq_flag || 
                    bne_flag  || slti_flag  || sltiu_flag || lui_flag ||
                    bgez_flag || lh_flag    || lhu_flag   || lb_flag  ||
                    lbu_flag || sb_flag || sh_flag) ? instr_in[15:0] : 16'hz;

assign address = (j_flag || jal_flag) ? instr_in[25:0] : 26'hz;     

endmodule
