`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/06 14:58:41
// Design Name: 
// Module Name: MULT
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module MUL(//�з�����
    input  [31:0] a,      // �з��ű�����
    input  [31:0] b,      // �з��ų���
    output [31:0] HI,     // ��32λ
    output [31:0] LO      // ��32λ
);

    wire signed [63:0] signed_result;   //�����з��ų˷����
    wire signed [63:0] signed_A;        //��չ���з���A
    wire signed [63:0] signed_B;        //��չ���з���B
    
    assign signed_A = { {32{a[31]}} , a };
    assign signed_B = { {32{b[31]}} , b };
    assign signed_result = signed_A * signed_B;
    
    assign HI = signed_result[63:32];
    assign LO = signed_result[31:0];
endmodule
