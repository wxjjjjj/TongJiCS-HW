`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/11 16:56:59
// Design Name: 
// Module Name: DIV
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module DIV(
    input  signed [31:0] dividend,  // ������
    input  signed [31:0] divisor,   // ����
    output signed [31:0] q,         // ��
    output signed [31:0] r          // ����
);
    assign q = (divisor != 0) ? dividend / divisor : 32'sh7fffffff; // 0������
    assign r = (divisor != 0) ? dividend % divisor : dividend;
endmodule